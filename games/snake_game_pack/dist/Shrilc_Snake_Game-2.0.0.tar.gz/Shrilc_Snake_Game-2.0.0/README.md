## Snake Game

This is a simple snake game in class based approach along with methods and packages to maintain code with ease.
This allows for flexibility and updates without making or modifying the based code.